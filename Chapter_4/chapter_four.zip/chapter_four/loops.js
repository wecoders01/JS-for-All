// Loops are some statements to reduce repeated task


// There are three kind of loops available

// For Loop
// While Loop
// Do While Loop