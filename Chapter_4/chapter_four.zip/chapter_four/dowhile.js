// Do While Loop

var isRunning = false

while (isRunning) {
    console.log('I am Running')
}

do {
    console.log('I am Running')
} while(isRunning)