// Continue Statement

for (var i = 0; i < 10; i++) {
    if (i === 3 || i === 7) {
        continue
    } else {
        console.log(i)
    }
}