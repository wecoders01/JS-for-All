var a = 10

var b

console.log(a)
console.log(b)

b = 20

console.log(b)

console.log(c)

var c = 50

console.log(c)

// Creational Phase
// a = undefined
// b = undefined
// c = undefined

// Executional Phase
// a = 10
// b = 20
