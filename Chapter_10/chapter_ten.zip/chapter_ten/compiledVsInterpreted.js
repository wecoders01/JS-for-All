// Javascript Compiled vs Interpreted

function a() {
    console.log('I am function a')
}

function b() {
    console.log('I am function b')
}

a()

b()

// JIT Just in Time