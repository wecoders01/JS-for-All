abc()

function abc() {
    console.log('I am Function')
}

// newAbc()

var newAbc = function () {
    console.log('I am New ABC Function')
}

newAbc()

// Creational Phase
// abc = ref
// newAbc = undefined

// Executional Phase



