var a = 10
var b = 2

// a > b true false

if (a > b) {
    console.log('A is greater than B')
}

if (a < b) {
    console.log('B is greater than A')
}

var n = 50

if (n % 2 === 0) {
    console.log(n + ' is Even Number')
}

if (n % 2 === 1) {
    console.log(n + ' is Odd Number')
}