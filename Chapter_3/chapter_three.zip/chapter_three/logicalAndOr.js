var name = ''

var fullname = name || 'HM Nayem'
console.log(fullname)

var isOk = false

isOk && console.log('Everything is OK')