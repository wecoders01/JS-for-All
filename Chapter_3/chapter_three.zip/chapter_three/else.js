var a = 10
var b = 20

// a > b true false

if (a > b) {
    console.log('A is greater than B')
} else {
    console.log('B is greater than A')
}

var n = 51

if (n % 2 === 0) {
    console.log(n + ' is Even Number')
} else {
    console.log(n + ' is Odd Number')
}