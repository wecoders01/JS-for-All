var a = 2
var b = 20

// a > b true false

if (a > b) {
    console.log('A is greater than B')
} else if (a < b) {
    console.log('B is greater than A')
} else {
    console.log('They Both are Same')
}

var n = 1

if (n === 0) {
    console.log(n + ' is zero')
} else if (n % 2 === 0) {
    console.log(n + ' is Even Number')
} else {
    console.log(n + ' is Odd Number')
}