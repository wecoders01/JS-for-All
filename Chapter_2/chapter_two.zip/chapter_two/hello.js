console.log('Hello World')
console.log('I Love Bangladesh')
console.log(45)
console.log(60.789)

console.log('My Fav No: ' + 9)
console.log(9 + 9)
console.log('9' + 9)