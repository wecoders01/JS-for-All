console.log('Hello World')
var str = 'string'
var number = 10 + (30 / 5) * 5

var a = 10
var b = 20

var c = a >= b