var name = 'HM Nayem'
var age = 25

// console.log(name)
// console.log(age)

// this some lines will log some outputs
console.log(name + ' knows Javascript.')
console.log('His age is only ' + age)
console.log( name + ' is creating a Javascript Course for All')
console.log('But his age is only ' + age)

var mathNumber = 10
var accountNumberDetailsId = 104
var account_number_details_id

/*
this is a comment
this is another comment
this is third line of comment

*/