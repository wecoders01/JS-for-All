// var str = '1000'
// var n = 10

// console.log(Number.parseInt(str))
// console.log(n.toString())

// console.log(Boolean(-Infinity))

// Falsy Values
''
0
null
undefined
NaN

console.log(Boolean(''))
console.log(Boolean('fdsfsdfsdfsd'))

console.log(Boolean(null))
console.log(Boolean(undefined))

console.log(Boolean(0))
console.log(Boolean(451))

console.log(true)
var x = true
console.log(x.toString())

// String Number Boolean